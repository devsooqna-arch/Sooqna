import { generateId } from "../../utils/ids";
import { nowIso } from "../../utils/time";
import { AppError } from "../../shared/errors/appError";
import type { MessagesRepository } from "./repositories/messages.repository";
import type { Conversation, Message, MessageType } from "./messages.types";

type CreateConversationInput = {
  participantIds: string[];
  participants: Conversation["participants"];
  listingId: string;
  listingSnapshot: Conversation["listingSnapshot"];
  createdBy: string;
};

type CreateMessageInput = {
  conversationId: string;
  senderId: string;
  type: MessageType;
  text: string;
  attachments?: unknown[];
};

export class MessagesService {
  constructor(private readonly repo: MessagesRepository) {}

  async createConversation(input: CreateConversationInput): Promise<Conversation> {
    if (!input.listingId.trim()) {
      throw new AppError(400, "listingId is required", "VALIDATION_ERROR");
    }
    if (!input.listingSnapshot.title.trim()) {
      throw new AppError(400, "listingSnapshot.title is required", "VALIDATION_ERROR");
    }

    const participantIds = Array.from(
      new Set(input.participantIds.map((participantId) => participantId.trim()).filter(Boolean))
    );
    if (!participantIds.length) {
      throw new AppError(400, "participantIds must contain at least one id", "VALIDATION_ERROR");
    }

    const now = nowIso();
    const conversation: Conversation = {
      id: generateId("conv"),
      participantIds,
      participants: input.participants,
      listingId: input.listingId,
      listingSnapshot: input.listingSnapshot,
      createdBy: input.createdBy,
      lastMessageText: "",
      lastMessageSenderId: "",
      lastMessageAt: null,
      lastMessageType: "text",
      isActive: true,
      createdAt: now,
      updatedAt: now,
    };
    return this.repo.createConversation(conversation);
  }

  async createMessage(input: CreateMessageInput): Promise<Message> {
    const now = nowIso();
    const conversation = await this.repo.findConversationById(input.conversationId);
    if (!conversation) throw new AppError(404, "Conversation not found", "NOT_FOUND");
    if (!conversation.participantIds.includes(input.senderId)) {
      throw new AppError(
        403,
        "You are not a participant in this conversation.",
        "FORBIDDEN"
      );
    }
    if (input.type === "text" && !input.text.trim()) {
      throw new AppError(400, "text is required for text messages", "VALIDATION_ERROR");
    }

    const message: Message = {
      id: generateId("msg"),
      conversationId: input.conversationId,
      senderId: input.senderId,
      type: input.type,
      text: input.text,
      attachments: input.attachments ?? [],
      isRead: false,
      readAt: null,
      createdAt: now,
      deletedAt: null,
    };

    await this.repo.createMessage(message);
    await this.repo.updateConversation({
      ...conversation,
      lastMessageText: input.text,
      lastMessageSenderId: input.senderId,
      lastMessageAt: now,
      lastMessageType: input.type,
      updatedAt: now,
    });

    return message;
  }

  async getConversation(id: string): Promise<Conversation | null> {
    return this.repo.findConversationById(id);
  }

  async getConversationForUser(id: string, userId: string): Promise<Conversation> {
    const conversation = await this.repo.findConversationById(id);
    if (!conversation) {
      throw new AppError(404, "Conversation not found", "NOT_FOUND");
    }
    if (!conversation.participantIds.includes(userId)) {
      throw new AppError(
        403,
        "You are not a participant in this conversation.",
        "FORBIDDEN"
      );
    }
    return conversation;
  }

  async getMessages(conversationId: string, userId: string): Promise<Message[]> {
    await this.getConversationForUser(conversationId, userId);
    return this.repo.listMessages(conversationId);
  }
}

