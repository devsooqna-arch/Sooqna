export type MessageType = "text" | "image" | "system";

export interface Conversation {
  id: string;
  participantIds: string[];
  participants: Record<string, { fullName: string; photoURL: string }>;
  listingId: string;
  listingSnapshot: {
    title: string;
    primaryImageURL: string;
  };
  createdBy: string;
  lastMessageText: string;
  lastMessageSenderId: string;
  lastMessageAt: string | null;
  lastMessageType: MessageType;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  type: MessageType;
  text: string;
  attachments: unknown[];
  isRead: boolean;
  readAt: string | null;
  createdAt: string;
  deletedAt: string | null;
}

